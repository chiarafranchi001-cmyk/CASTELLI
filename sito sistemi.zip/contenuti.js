// Contenuti della pagina. Per usare una foto, scrivi il nome del file (es. "castelli.jpg") nel campo "foto".
const CONTENUTI = {
  titolo: "Castelli",
  benvenuto: "Benvenuti a Castelli, borgo di montagna ai piedi del Gran Sasso dove l’arte della maiolica vive da oltre cinque secoli.",
  intro: [
    "Castelli è un suggestivo borgo montano dell’Abruzzo, in provincia di Teramo, arroccato su uno sperone roccioso ai piedi del massiccio del Gran Sasso d’Italia e immerso nell’omonimo Parco Nazionale. Il centro storico si trova tra i 498 e i 500 m s.l.m. Riconosciuto tra «I Borghi più Belli d’Italia», è circondato da rigogliosi boschi e torrenti ed è facilmente raggiungibile dall’autostrada A24, uscita Colledara-San Gabriele.",
    "La sua vera essenza risiede in una gloriosa e secolare tradizione della maiolica, che da oltre cinque secoli rende questo centro celebre a livello internazionale. Immerso tra natura incontaminata e arte antica, Castelli accoglie i viaggiatori con il calore delle sue botteghe artigiane vive e con affascinanti percorsi per l’escursionismo."
  ],
  hero: { didascalia: "Il borgo di Castelli sul suo sperone roccioso, ai piedi del Gran Sasso", foto: "" },
  storia: [
    { periodo: "Epoca romana e alto Medioevo", titolo: "Le origini e il nome", testo: "L’impianto originale del borgo risale all’epoca romana o italica, nell’Ager Hatrianus citato da Plinio il Vecchio. Durante le invasioni barbariche le popolazioni si arroccarono sul sito fortificato, dando origine al toponimo «Li Castelli». Secondo una fonte, la lavorazione ceramica locale potrebbe risalire già all’epoca etrusca." },
    { periodo: "Intorno all’800 – 1117", titolo: "L’Abbazia di San Salvatore e i benedettini", testo: "Intorno all’anno 800 fu fondata l’Abbazia di San Salvatore con i monaci benedettini cassinesi, decisivi per lo sviluppo locale e per la produzione di ceramiche d’uso quotidiano. Nel 1117 il convento diede asilo a Papa Pasquale II, ottenendo da lui importanti benefici ecclesiastici e l’autonomia della figura dell’Abate." },
    { periodo: "Prima metà del XVI secolo", titolo: "I Marchesi Alarçon y Mendoza", testo: "Con il passaggio del territorio ai Marchesi spagnoli Alarçon y Mendoza, la maiolica di Castelli aprì le sue esportazioni alle più illustri casate nobiliari d’Italia e d’Europa. A questo periodo risalgono i primi capolavori, come il celebre corredo vascolare Orsini-Colonna e il primo soffitto di San Donato." },
    { periodo: "XVII e XVIII secolo", titolo: "L’epoca d’oro dell’Istoriato e la «Rivolta dei Baroni»", testo: "Il Seicento e il Settecento segnarono la massima fioritura dello stile istoriato e del Barocco in maiolica, grazie alle celebri botteghe Grue, Cappelletti e Gentile. Tra i grandi maestri spicca Francesco Antonio Grue, dottore in teologia e promotore della «Rivolta dei Baroni» contro i balzelli feudali posti sulle ceramiche." },
    { periodo: "Ottocento – 1906", titolo: "Il colore rosso e la scuola d’arte", testo: "Nel XIX secolo l’artigianato castellano si rinnovò con l’introduzione del colore rosso, che diede vita a decori iconici come il mazzetto floreale. Nel 1906 venne fondata la Regia Scuola d’Arte per codificare e trasmettere il patrimonio manifatturiero." },
    { periodo: "1915 e storia recente", titolo: "Il muraglione e la ricostruzione", testo: "Nel 1915, a causa delle conseguenze del terremoto di Avezzano, la scomparsa dell’ultima fila di case diede spazio al panoramicissimo muraglione detto «lo steccato». In epoca contemporanea il borgo ha affrontato con fermezza anche i sismi del 2009 e 2016, preservando il proprio decoro e l’inestimabile identità artigianale." }
  ],
  ceramica: {
    foto: { didascalia: "Maioliche decorate a mano nelle botteghe di Castelli", foto: "" },
    testi: [
      "La nascita della ceramica a Castelli è legata alla straordinaria ricchezza di risorse naturali del territorio: cave d’argilla, giacimenti di silice, corsi d’acqua e boschi di faggio per la legna dei forni.",
      "La lavorazione artigianale parte dalla modellazione dell’argilla cruda, che viene cotta a 980 °C ottenendo il «biscotto». Poi viene immersa in uno smalto impermeabilizzante a base di silice e stagno, decorata rigorosamente a mano con pennelli e ossidi metallici e infine sottoposta a una seconda cottura.",
      "La tavolozza classica castellana si basa tradizionalmente su cinque colori storici (blu, arancio Castelli, verde ramina, giallo e manganese marrone scuro), a cui si è aggiunto il rosso nell’Ottocento. Dai vasi da farmacia cinquecenteschi agli ornati compendiari, fino alle straordinarie scenografie istoriate barocche e ai soggetti tradizionali come rose, uccellini e animaletti modellati, le maioliche di Castelli sono oggi ammirate nei più prestigiosi musei del mondo, tra cui il Louvre, il British Museum, l’Ermitage e il Metropolitan.",
      "Oggi nelle botteghe si producono stoviglie tradizionali, pezzi d’arredo, sculture (come animaletti o quadri) e opere contemporanee."
    ],
    visita: [
      "il Museo delle Ceramiche, presso il Palazzo Museale dell’Artigianato",
      "le botteghe storiche dei ceramisti",
      "il soffitto maiolicato di San Donato",
      "la Raccolta contemporanea del Liceo Artistico Grue"
    ]
  },
  vedere: [
    { titolo: "Chiesa di San Donato", testo: "Situata nella vicina frazione omonima, è una piccola chiesa celebre per il suo eccezionale soffitto di oltre 800 mattoni in maiolica dipinta (1615-1617), definito da Carlo Levi «la Sistina della Maiolica».", foto: { didascalia: "Il soffitto in maiolica dipinta della chiesa di San Donato", foto: "" } },
    { titolo: "Museo delle Ceramiche", testo: "Provvisoriamente allestito presso il Palazzo Museale dell’Artigianato, custodisce un’ampia collezione cronologica di maioliche dal XV al XX secolo e comprende la ricostruzione dell’antica bottega con l’antico forno." },
    { titolo: "Chiesa di San Giovanni Battista", testo: "Principale chiesa parrocchiale del borgo, costruita con elementi dell’antica Abbazia di San Salvatore. Conserva al suo interno una pregiata Madonna lignea del XIII secolo e una pala d’altare in maiolica del 1647 dipinta da Francesco Grue." },
    { titolo: "Liceo Artistico «F.A. Grue» e Presepe Monumentale", testo: "Storica scuola d’arte che ospita il Presepe Monumentale, composto da 54 statue ceramiche a grandezza naturale (esposto in Piazza San Pietro per il Natale 2020), e una raccolta d’arte ceramica contemporanea con oltre 500 opere." },
    { titolo: "Il Belvedere («Lo Steccato») e il quartiere La Portella", testo: "Panoramicissimo muraglione ad archi affacciato sul torrente Leomogna, all’estremità del borgo, dove sorgeva la porta d’accesso con la storica casa del maestro ceramista Orazio Pomnei.", foto: { didascalia: "Il muraglione ad archi sul torrente Leomogna", foto: "" } }
  ],
  saporiIntro: "La gastronomia di Castelli unisce la ricchezza della cucina teramana alle ricette tipiche di montagna.",
  sapori: [
    { titolo: "Primi piatti", testo: "Spiccano il timballo della tradizione, la chitarra con le pallottine (polpettine di carne), le scrippelle ’mbusse (crepes in brodo), i ravioli dolci e l’esclusivo piatto locale dei maltagliati con le voliche (orapi, una verdura spontanea che cresce in alta montagna)." },
    { titolo: "Pani, salumi e fritti", testo: "I formaggi e i salumi locali vengono serviti con la scarapiccia (una pizza tradizionale) o con la fragrante ’mmazzafame (frittella tipica)." },
    { titolo: "Secondi piatti", testo: "Agnello e carni miste alla brace, le classiche salsicce locali e gli arrosticini abruzzesi." },
    { titolo: "Dolci e pasticceria", testo: "Il re dei dolci è il Mostacciolo di Castelli, un biscotto morbido a base di mandorle tostate, miele, cacao, caffè, farina, tuorli e olio extravergine d’oliva. A questo si affiancano i dolci della festa (la «pizza dolce» e i fritti di latte) e il tradizionale «vassoio degli sposi», composto da finocchietti alle mandorle, bocconotti con marmellata mista, torroncini, amaretti e sfogliatelle.", foto: { didascalia: "Il Mostacciolo di Castelli", foto: "" } }
  ],
  eventi: [
    { titolo: "Lancio del piatto", quando: "15 agosto", testo: "Manifestazione folkloristica e ludica estiva al belvedere, in cui cittadini e visitatori si sfidano a lanciare piatti in ceramica grezza (biscotto) facendoli volare oltre il fiume sottostante.", foto: { didascalia: "Piatti in ceramica grezza lanciati dal belvedere", foto: "" } },
    { titolo: "Mostra Mercato dell’Artigianato Ceramico", testo: "Evento con oltre sessant’anni di storia che trasforma le vie e le botteghe del centro storico in spazi espositivi per i capolavori dei maestri ceramisti." },
    { titolo: "Agosto a Castelli", quando: "Tra fine luglio e inizio settembre", testo: "Ricco programma di manifestazioni culturali estive: musica, cinema, spettacoli circensi e teatro." },
    { titolo: "Buongiorno Ceramica", quando: "Maggio", testo: "Fine settimana interamente dedicato alla cultura ceramica, con laboratori aperti, mostre ed edizioni speciali di lavorazione dell’argilla." },
    { titolo: "Festa della Madonna degli Angeli", testo: "Ricorrenza legata all’antico convento francescano, durante la quale si rinnova lo storico Privilegio di Assisi per l’ottenimento dell’indulgenza plenaria." },
    { titolo: "Natale a Castelli", quando: "Periodo natalizio", testo: "Insieme di appuntamenti culturali, religiosi ed espositivi organizzati nel periodo delle festività natalizie." }
  ],
  faq: [
    { d: "Dove si trova il borgo di Castelli e come ci si arriva?", r: "Castelli si trova in Abruzzo, in provincia di Teramo, ai piedi del Gran Sasso, ed è raggiungibile dall’autostrada A24 tramite l’uscita Colledara-San Gabriele. Per la mappa esatta e i dettagli di viabilità, consulta il sito ufficiale del Comune." },
    { d: "Per quale motivo la ceramica di Castelli è famosa nel mondo?", r: "Il borgo vanta una secolare scuola ceramica i cui storici pezzi istoriati e maiolicati sono esposti in illustri musei internazionali come il Louvre, il British Museum e l’Ermitage." },
    { d: "Che cos’è la celebre «Sistina della Maiolica»?", r: "È l’appellativo dato da Carlo Levi al soffitto della chiesa di San Donato, interamente composto da oltre 800 mattoni in maiolica dipinta realizzati nel Seicento." },
    { d: "Quali sono le specialità culinarie da assaggiare assolutamente?", r: "Tra i piatti principali spiccano i maltagliati con le voliche (orapi di montagna), la chitarra con le pallottine e i rinomati mostaccioli morbidi a base di mandorle e miele." },
    { d: "In cosa consiste l’evento del «Lancio del Piatto»?", r: "È una gara goliardica che si tiene ogni 15 agosto presso il belvedere, durante la quale si lanciano piatti in ceramica grezza verso la valle sottostante." }
  ]
};
